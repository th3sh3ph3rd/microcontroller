
#include <game.h>

int main(void)
{
    game_init();

    game_run();
    
    return 0;
}

