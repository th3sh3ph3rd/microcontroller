#include <stdint.h>

#ifndef __MAC__
#define __MAC__

const uint8_t mac_address[6] = { 0x58, 0xbd, 0xa3, 0x4b, 0xf6, 0x80 };

#endif

